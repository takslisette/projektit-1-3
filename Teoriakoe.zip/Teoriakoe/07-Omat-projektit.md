[← Sisällysluettelo](README.md)

# Omat projektit

## 1. DOM-skriptaus – Ennen koulua

Natiivi JS, lomake, validointi, localStorage. `loadTasks()` lukee ja tarkistaa tallennetun taulukon; `saveTasks()` tallentaa; `showError()` ja `clearError()` hallitsevat virhettä; `createId()` luo tunnisteen; `renderTasks()` piirtää listan; `updateFilterButtons()` päivittää suodattimet.

Lisäys: submit → preventDefault → trim → tarkista tyhjä ja alle 3 merkkiä → clearError → luo objekti → push → saveTasks → currentFilter = all → updateFilterButtons → renderTasks → tyhjennä ja fokusoi kenttä.

```js
const newTask = {id: createId(), text: text, completed: false};
tasks.push(newTask);
saveTasks();
```
`taskList.replaceChildren()` tyhjentää vanhan listan. `filter(task => !task.completed)` valitsee keskeneräiset; `.length` laskee määrän. `filter(task => task.completed)` valitsee tehdyt. Poistossa säilytetään eri ID:n tehtävät. Checkboxin change-kuuntelija asettaa `task.completed = checkbox.checked`, tallentaa ja piirtää uudelleen.

Tallennusavain on `ennen-koulua-tehtavat`. JSON.stringify tallentaa taulukon; JSON.parse palauttaa sen. loadTasks tarkistaa Array.isArray ja ominaisuuksien tyypit; catch palauttaa tyhjän taulukon.

## 2. Hockey Center

Natiivi JS, fetch, JSON, REST API. `getTeams`, `getGames`, `getStandings`, `getTeamSchedule` hakevat tiedot; vastaavat `display...`-funktiot näyttävät ne. `populateTeamSelect` täyttää valikon. `allTeams` säilyttää haetun datan hakusuodatusta varten.

```js
const filteredTeams = allTeams.filter(team =>
    team.teamName.default.toLowerCase().includes(searchText)
);
const sortedTeams = [...teams].sort((a, b) => b.points - a.points);
```
Hakuteksti muutetaan pieniksi kirjaimiksi. sort vertaa pisteitä laskevasti; spread kopioi taulukon. `option.value` on joukkueen lyhenne ja `option.textContent` nimi. change-kuuntelija hakee valitun joukkueen otteluohjelman. `score ?? "-"` säilyttää nollan mutta korvaa null/undefined-arvon viivalla. API käyttää CORS-välityspalvelinta.

## 3. Hockey Center 2.0

Sama perusidea jQueryllä ja Bootstrapilla. `$.ajax()` korvaa fetchin, `.on()` kuuntelijat, `$()` DOM-valinnat, `.text()` tekstin, `.append()` lisäämisen. `initializeSearch`, `initializeTeamSelect`, `initializeFavorites` asettavat kuuntelijat. document.ready käynnistää ne sekä getTeams, getGames ja getStandings.

```js
const teamName = $("#teamSelect option:selected").text();
localStorage.setItem("favoriteTeam", teamName);
const savedFavorite = localStorage.getItem("favoriteTeam");
```
Suosikki on merkkijono, joten JSON-muunnosta ei tarvita. Projektissa 1 tallennetaan objektitaulukko. Projektissa 3 käytetään method chainingia, esimerkiksi `$("<img>").attr("src", team.teamLogo).addClass("team-logo")`.

Koodiesimerkit ovat lyhennettyjä tai havainnollistavia; tarkka toteutus löytyy projektien script.js-tiedostoista.
