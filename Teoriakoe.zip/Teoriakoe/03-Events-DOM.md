[← Sisällysluettelo](README.md)

# Events ja DOM (WS03–04)

DOM = Document Object Model, HTML-dokumentin puurakenne. JavaScript voi muuttaa sitä.

| Tapahtuma | Milloin |
|---|---|
| click / dblclick | Klikkaus / kaksoisklikkaus |
| mouseover / mouseenter / mouseleave | Hiiren liike elementtiin tai pois |
| focus / blur | Kenttä aktivoituu / menettää fokuksen |
| input / change | Arvo muuttuu / valinta vahvistuu |
| submit | Lomake lähetetään |
| keydown / keyup | Näppäin painetaan / vapautetaan |

```js
button.addEventListener("click", showTable);
form.addEventListener("submit", function(event) {
    event.preventDefault();
});
```
`showTable` välittää funktion; `showTable()` kutsuu heti. Dynaaminen kuuntelija lisätään JS:ssä, inline-kuuntelija HTML:n onclick-attribuutissa. `preventDefault()` estää oletustoiminnon. `event.key`, `event.code`, `event.shiftKey`, `event.ctrlKey` ja `event.altKey` kuvaavat näppäintapahtumaa.

| Komento | Merkitys |
|---|---|
| getElementById("title") | ID ilman risuaitaa |
| querySelector("#title") | Ensimmäinen CSS-valitsinta vastaava |
| querySelectorAll(".item") | Kaikki sopivat |
| textContent / innerHTML | Teksti / tulkittava HTML |
| value / checked | Kentän arvo / checkboxin tila |
| style / hidden / disabled | Ulkoasu / piilotus / käytöstä poisto |
| classList.add/remove/toggle/contains | CSS-luokan hallinta |
| createElement | Luo elementin |
| appendChild / append | Lisää DOMiin |
| remove / replaceChildren | Poistaa / korvaa lapset |
| closest | Lähin sopiva elementti itsestä ylöspäin |

```js
const item = document.createElement("li");
item.textContent = "Tehtävä";
container.appendChild(item);
```
Käyttäjän tekstille suosi textContentia. WS03:n palautelomake käyttää input-tapahtumaa merkkilaskuriin ja tarkistaa 10–200 merkin pituuden. WS04:n eläinhavaintolomakkeen järjestys: submit → preventDefault → kenttien luku → validointi → tr ja td → poistopainike ja kuuntelija → lisää taulukkoon → reset.
