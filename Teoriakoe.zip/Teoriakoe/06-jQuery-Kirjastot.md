[← Sisällysluettelo](README.md)

# JavaScript-kirjastot (WS09)

jQuery: DOM, tapahtumat, AJAX. Axios: HTTP-pyynnöt. Chart.js: kaaviot. Bootstrap: käyttöliittymä. SweetAlert2: ilmoitukset. Lataa kirjasto ennen omaa sitä käyttävää skriptiä.

| Natiivi JS | jQuery |
|---|---|
| querySelector("#id") | $("#id") |
| textContent | .text() |
| innerHTML | .html() |
| value | .val() |
| classList.add/remove/toggle | .addClass()/.removeClass()/.toggleClass() |
| addEventListener | .on() |
| createElement("div") | $("<div>") |
| appendChild | .append() |
| replaceChildren() | .empty() |
| setAttribute | .attr() |
| fetch | $.ajax() |

```js
$("#teamSearch").on("input", function() {
    const searchText = $(this).val().toLowerCase();
});
$.ajax({
    url: API_URL,
    method: "GET",
    dataType: "json",
    timeout: 15000,
    success: function(data) { displayTeams(data.standings); },
    error: function(xhr, status, error) { console.error(error); }
});
```
`$(this)` käärii kuuntelijan elementin jQuery-objektiksi. dataType kertoo odotetun vastauksen muodon; JSON jäsennetään automaattisesti. timeout 15000 = 15 sekuntia. success/error ovat callback-funktioita.

```js
$(document).ready(function() { getTeams(); });
const response = await axios.get(url);
const data = response.data;
```
Axiosin vastausdata on `response.data`, fetchissä käytetään `response.json()`. Axios hylkää oletuksena epäonnistuneet HTTP-statukset.

WS09:n mukana toimitettu sääskripti hakee ennusteen suoraan Axiosilla, käyttää `response.data.list`, `slice(0, 12)`, `map()`, `dt_txt` ja `main.temp`. Se piirtää Chart.js-kaavion ja vaihtaa kaaviotyyppiä. `line` = viiva, `bar` = pylväs. Vanha kaavio tuhotaan destroy()-metodilla ennen uuden luontia.

```js
new Chart(canvas, {type: "line", data: {
    labels: times, datasets: [{label: "Lämpötila", data: temperatures}]
}});
```
