# Web Development – teoriakokeen kertaus

Suomenkielinen opiskelupaketti. AI-avusteiset muistiinpanot perustuvat kurssin materiaaleihin, omiin projekteihin ja aiempaan teoriakokeeseen. Käytä ennen koetta; kokeessa vain opettajan sallimia materiaaleja.

## Sisällysluettelo

- [HTML, CSS ja web-kehitys (WS01)](01-HTML-CSS.md)
- [JavaScript Basics (WS02)](02-JavaScript.md)
- [Events ja DOM (WS03–04)](03-Events-DOM.md)
- [Forms ja localStorage (WS05)](04-Forms-LocalStorage.md)
- [AJAX, REST API, JSON ja XML (WS07–08)](05-AJAX-JSON-XML.md)
- [JavaScript-kirjastot (WS09)](06-jQuery-Kirjastot.md)
- [Omat projektit](07-Omat-projektit.md)
- [Harjoitustentti – 20 kysymystä](08-Harjoitustentti.md)
- [Pikakertaus ja tiedostohakemisto](09-Pikakertaus.md)

## Lähteet ja rajaukset

Kurssin ja omat workshop-ZIPit sekä DOM-skriptaus, Hockey Center ja Hockey Center 2.0. Omat WS05–09 eivät olleet mukana; WS06 ei löytynyt kurssipaketista. Esimerkit ovat osin yleisiä ja lyhennettyjä. Live-API-yhteyksiä ei testattu.
