[← Sisällysluettelo](README.md)

# JavaScript Basics (WS02)

`let` voidaan sijoittaa uudelleen, `const` ei (objektin sisältöä voi silti muuttaa), `var` on vanhempi määrittelytapa. Tyypit: string, number, boolean, undefined, null, object; array on erityinen objekti.

```js
let age = 23;
const animals = ["Tiikeri", "Panda", "Elefantti"];
const task = {id: "123", text: "Pakkaa laukku", completed: false};
animals[0]; // Tiikeri
animals.length; // 3
```

| Operaattori | Merkitys |
|---|---|
| `=` | Sijoitus |
| `==`, `===` | Löyhä ja tiukka vertailu |
| `!==` | Tiukasti erisuuri |
| `>`, `<`, `>=`, `<=` | Suuruusvertailu |
| `&&`, `\|\|`, `!` | JA, TAI, EI |
| `++`, `+=` | Kasvatus, lisääminen |
| `??` | Vara-arvo vain null/undefined-arvoille |

`5 == "5"` on true, `5 === "5"` on false.

```js
let userAge = prompt("How old are you?");
if (userAge >= 18) {
    alert("You are an adult!");
} else {
    alert("You are a minor!");
}
function greetUser(name) {
    console.log("Hello " + name + "!");
}
greetUser("Panda");
```
`prompt()` palauttaa merkkijonon tai peruutettaessa null. `Number()` muuntaa luvuksi. Parametri on funktion määrittelyssä, argumentti kutsussa. `return` palauttaa arvon ja lopettaa funktion.

| Metodi | Toiminto |
|---|---|
| push / pop | Lisää / poistaa lopusta |
| forEach | Käy alkiot läpi |
| filter | Uusi taulukko ehdon täyttävistä |
| map | Uusi taulukko muunnetuista |
| find / some | Ensimmäinen sopiva / löytyykö sopiva |
| sort | Järjestää taulukon paikallaan |
| includes | Sisältääkö arvon |

```js
for (let i = 0; i < animals.length; i++) {
    console.log(animals[i]);
}
animals.forEach(animal => console.log(animal));
const name = "Panda";
console.log(`Eläin: ${name}`);
```
