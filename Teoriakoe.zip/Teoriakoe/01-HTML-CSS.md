[← Sisällysluettelo](README.md)

# HTML, CSS ja web-kehitys (WS01)

HTML = rakenne, CSS = ulkoasu, JavaScript = toiminnallisuus. Front-end toimii käyttäjän selaimessa; back-end toteuttaa palvelinlogiikan ja käsittelee tietokantoja. Full-stack kattaa molemmat. JavaScript syntyi vuonna 1995. Node.js on JavaScriptin suoritusympäristö.

| HTML | Merkitys |
|---|---|
| `h1`, `h2`, `p` | Otsikot ja kappale |
| `div`, `img`, `a` | Sisältöalue, kuva, linkki |
| `form`, `input`, `button` | Lomake, kenttä, painike |
| `ul`, `ol`, `li` | Listat ja listan alkio |
| `table`, `tr`, `th`, `td` | Taulukko, rivi, otsikkosolu, solu |
| `select`, `option` | Alasvetovalikko ja vaihtoehto |

```html
<link rel="stylesheet" href="style.css">
<script src="script.js" defer></script>
```
`defer` antaa HTML:n jäsentyä ennen skriptin suoritusta.

```css
h1 { color: red; }
#heading { font-size: 24px; }
.highlight { background-color: yellow; }
.hidden { display: none; }
```
ID on yksilöllinen, class voi toistua. `margin` = ulkopuolinen väli, `padding` = sisäpuolinen väli, `border` = reunus.

DevTools: Elements = HTML/CSS, Console = virheet ja `console.log()`, Network = verkkopyynnöt, Application = tallennustila, Sources = debuggaus.

Git on versionhallinta, GitHub repositorioiden verkkopalvelu. Repository sisältää tiedostot ja historian; commit tallentaa muutoksen, push vie commitit etärepositorioon, pull hakee ja yhdistää muutokset, clone kopioi repositorion. Netlify ja GitHub Pages julkaisevat sivuja.

```bash
git add .
git commit -m "Update project"
git push
```
