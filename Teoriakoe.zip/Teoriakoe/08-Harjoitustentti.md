[← Sisällysluettelo](README.md)

# Harjoitustentti – 20 kysymystä

Oma harjoitus, ei oikea koe. Avaa vastaukset vasta yrittämisen jälkeen.

### 1. Front-endin kolme kulmakiveä?

<details>
<summary>Oikea vastaus</summary>

HTML, CSS, JavaScript

</details>

### 2. Mikä DOM on?

<details>
<summary>Oikea vastaus</summary>

HTML-dokumentin objektimalli.

</details>

### 3. Mitä `5 === "5"` palauttaa?

<details>
<summary>Oikea vastaus</summary>

false, tyypit eroavat.

</details>

### 4. Valitse kaikki .team-card-elementit.

<details>
<summary>Oikea vastaus</summary>

`document.querySelectorAll(".team-card")`

</details>

### 5. Mitä preventDefault tekee submitissa?

<details>
<summary>Oikea vastaus</summary>

Estää oletuslähetyksen.

</details>

### 6. Mikä tapahtuma sopii reaaliaikaiseen hakuun?

<details>
<summary>Oikea vastaus</summary>

input

</details>

### 7. Mitä JSON.stringify tekee?

<details>
<summary>Oikea vastaus</summary>

Muuntaa JS-arvon JSON-tekstiksi.

</details>

### 8. Mitä `tasks.filter(task => !task.completed)` palauttaa?

<details>
<summary>Oikea vastaus</summary>

Keskeneräiset tehtävät.

</details>

### 9. Mitä AJAX mahdollistaa?

<details>
<summary>Oikea vastaus</summary>

Datan hakemisen ilman koko sivun uudelleenlatausta.

</details>

### 10. Mitä response.ok tarkistaa?

<details>
<summary>Oikea vastaus</summary>

HTTP-status 200–299.

</details>

### 11. Mikä jQuery-metodi vastaa addEventListeneria?

<details>
<summary>Oikea vastaus</summary>

`.on()`

</details>

### 12. Mikä kirjasto piirtää sääkaavion?

<details>
<summary>Oikea vastaus</summary>

Chart.js

</details>

### 13. Täydennä `document.____("#task-input")`.

<details>
<summary>Oikea vastaus</summary>

querySelector

</details>

### 14. Täydennä `JSON.____(tasks)` tallennusta varten.

<details>
<summary>Oikea vastaus</summary>

stringify

</details>

### 15. Täydennä `await response.____()` JSON-vastaukselle.

<details>
<summary>Oikea vastaus</summary>

json

</details>

### 16. Täydennä `$("#teamSelect").____()` arvon lukemiseen.

<details>
<summary>Oikea vastaus</summary>

val

</details>

### 17. Täydennä `tasks.____(newTask)`.

<details>
<summary>Oikea vastaus</summary>

push

</details>

### 18. Järjestä: appendChild, createElement, textContent.

<details>
<summary>Oikea vastaus</summary>

createElement → textContent → appendChild

</details>

### 19. Järjestä: displayTeams, response.json, fetch, response.ok.

<details>
<summary>Oikea vastaus</summary>

fetch → response.ok → response.json → displayTeams

</details>

### 20. Järjestä: saveTasks, trim, renderTasks, push, preventDefault, validointi, objektin luonti.

<details>
<summary>Oikea vastaus</summary>

preventDefault → trim → validointi → objektin luonti → push → saveTasks → renderTasks

</details>

## Aiempi teoriakoe (14/14)

1. HTML, CSS, JavaScript
2. HTML: sivun rakenne
3. CSS: tyylit
4. 1995
5. Interaktiivisuus
6. CSS: tyylit
7. HTML ja JavaScript
8. Lomakkeiden tarkastaminen (annetuista vaihtoehdoista)
9. Palvelinlogiikka
10. PHP (annetuista vaihtoehdoista)
11. Front-end ja back-end
12. Käyttöliittymä ja toiminnallisuus
13. Angular, Vue.js, React, jQuery (Angular ja Vue ovat kehyksiä)
14. Git: versionhallinta
