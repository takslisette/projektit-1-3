[← Sisällysluettelo](README.md)

# Pikakertaus ja tiedostohakemisto

| Tarve | Komento |
|---|---|
| Valitse ID / CSS-valitsin / kaikki | getElementById / querySelector / querySelectorAll |
| Luo / lisää / poista | createElement / appendChild / remove |
| Teksti / HTML / kenttä | textContent / innerHTML / value |
| Kuuntelija / oletustoiminnon esto | addEventListener / preventDefault |
| CSS-luokka | classList.add/remove/toggle |
| Siisti / laske | trim / length |
| Lisää / suodata / käy läpi / järjestä | push / filter / forEach / sort |
| Haku | toLowerCase / includes |
| Tallenna / hae | localStorage.setItem / getItem |
| JSON-tekstiksi / takaisin | JSON.stringify / JSON.parse |
| API | fetch → response.ok → response.json → DOM |
| XML | response.text / DOMParser |
| jQuery | $ / .on / .val / .text / $.ajax |
| Axios / kaavio | axios.get / new Chart |

## Tiedostot alkuperäisissä repoissa

| Aihe | Tiedosto |
|---|---|
| HTML | Oma WS01_HTML_basics/index.html |
| JS | Oma WS02_JS_basics/js/script.js |
| Events | Oma WS03_JS_events/js/script.js |
| DOM | Oma WS04_DOM/js/script.js |
| Forms | Kurssi WS05_Forms_Localstorage/Workshop05/js/script.js |
| XMLHttpRequest | Kurssi WS07_AJAX/class_exercise/ajaxdemo-weathermap.js |
| XML | Kurssi WS08_XML/script.js |
| Kirjastot | Kurssi WS09_JS_libraries/script.js ja README.md |
| Validointi, localStorage | DOM-skriptaus/script.js |
| Fetch, JSON | hockey-center/script.js |
| jQuery, AJAX | Hockey-Center-2.0/script.js |

Kertaa ensin DOM ja events, sitten validointi ja localStorage, sitten fetch ja jQuery. Tee harjoitustentti ja kertaa virheet. Priorisointi on arvio, ei opettajan vahvistama kysymysjakauma.
