[← Sisällysluettelo](README.md)

# Forms ja localStorage (WS05)

Validointi tarkistaa syötteen. `.value` lukee arvon, `.trim()` poistaa reunavälilyönnit, `.length` laskee merkit, `.focus()` aktivoi kentän ja `.reset()` palauttaa lomakkeen alkuarvot.

```js
const text = input.value.trim();
if (text.length < 3) {
    showError("Liian lyhyt teksti");
    return;
}
```
localStorage säilyttää merkkijonoja avain-arvopareina yleensä myös selaimen sulkemisen jälkeen. sessionStorage säilyy sivun päivityksessä, mutta päättyy normaalisti välilehden istunnon päättyessä.

```js
localStorage.setItem("animal", "Panda");
const animal = localStorage.getItem("animal");
localStorage.removeItem("animal");
```
`clear()` poistaa originin kaikki localStorage-arvot. Puuttuva avain palauttaa null.

```js
localStorage.setItem("tasks", JSON.stringify(tasks));
const saved = localStorage.getItem("tasks");
const restored = saved ? JSON.parse(saved) : [];
```
stringify = JS-arvo → JSON-teksti; parse = JSON-teksti → JS-arvo. Virheellinen JSON voi aiheuttaa poikkeuksen; try/catch käsittelee sen. Pelkän merkkijonon tallennus ei tarvitse JSON-muunnosta.
