[← Sisällysluettelo](README.md)

# AJAX, REST API, JSON ja XML (WS07–08)

AJAX = Asynchronous JavaScript and XML: palvelindatan hakeminen ilman koko sivun uudelleenlatausta. API = Application Programming Interface. REST API tarjoaa resursseja HTTP:n kautta. AJAX voi käyttää JSONia tai XML:ää.

| HTTP | Merkitys |
|---|---|
| GET / POST | Haku / lähetys tai luonti |
| PUT / PATCH / DELETE | Korvaus / osapäivitys / poisto |
| 200 / 201 | OK / Created |
| 400 / 401 / 403 | Virheellinen pyyntö / tunnistautuminen / ei oikeutta |
| 404 / 500 | Ei löydy / palvelinvirhe |

```js
async function getTeams() {
    try {
        const response = await fetch(API_URL);
        if (!response.ok) throw new Error("Virhe");
        const data = await response.json();
        displayTeams(data.standings);
    } catch (error) {
        console.error(error);
    }
}
```
`async`-funktio palauttaa Promisen; `await` odottaa sen valmistumista kyseisessä funktiossa. `response.ok` tarkistaa 200–299-statuksen. fetch ei hylkää Promisea pelkän HTTP-virhestatuksen vuoksi.

```js
const xhr = new XMLHttpRequest();
xhr.open("GET", url, true);
xhr.onload = function() {
    if (xhr.status === 200) {
        const data = JSON.parse(xhr.responseText);
        console.log(data);
    }
};
xhr.send();
```
true = asynkroninen. Järjestys: luo → open → kuuntelija → send → käsittele vastaus. CORS säätelee eri originien välisiä selainpyyntöjä; Hockey Center käyttää välityspalvelinta.

```json
{"standings":[{"teamName":{"default":"Panda"},"points":100}]}
```
`data.standings[0].points` on 100. JSON = JavaScript Object Notation. XML = Extensible Markup Language.

```xml
<weather><city>Helsinki</city><temp>5</temp></weather>
```
```js
const response = await fetch(url);
const xmlText = await response.text();
const xmlDoc = new DOMParser().parseFromString(xmlText, "text/xml");
```
DOMParser on täydentävä yleisesimerkki. WS08 käyttää OpenWeatherMapia; q = kaupunki, units=metric = Celsius, mode=xml = XML-vastaus, appid = API-avain.
